package com.app.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.Transaction;
import com.app.repo.TransactionRepository;

@Service
public class TransactionService {
	@Autowired
	private TransactionRepository transactionRepository;

	public List<Transaction> getTransactionsInLast24Hours() {
		LocalDateTime now = LocalDateTime.now();
		LocalDateTime yesterday = now.minusDays(1);
		return transactionRepository.findByTimestampBetween(yesterday, now);
	}
	public List<Transaction> getTransactionHistory(LocalDateTime start, LocalDateTime end) {
	    return transactionRepository.findByTimestampBetween(start, end);
	}
}
