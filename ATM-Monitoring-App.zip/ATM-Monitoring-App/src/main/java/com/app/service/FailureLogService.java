package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.FailureLog;
import com.app.repo.FailureLogRepository;

@Service
public class FailureLogService {
    @Autowired
    private FailureLogRepository failureLogRepository;

    public List<FailureLog> getAllFailures() {
        return failureLogRepository.findAll();
    }

    public FailureLog addFailure(FailureLog failureLog) {
        return failureLogRepository.save(failureLog);
    }
}
