package com.app.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.entity.MediaFile;
import com.app.repo.MediaFileRepository;

@Service
public class MediaService {
    @Autowired
    private MediaFileRepository mediaFileRepository;

    public List<MediaFile> getMediaFilesByTimeRange(LocalDateTime startTime, LocalDateTime endTime) {
        // Assuming a custom query method in MediaFileRepository to filter by time range
        return mediaFileRepository.findByStartTimeBetween(startTime, endTime);
    }
}
