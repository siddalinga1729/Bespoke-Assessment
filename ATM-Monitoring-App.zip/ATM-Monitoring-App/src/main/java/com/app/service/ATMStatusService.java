package com.app.service;

import org.springframework.stereotype.Service;

@Service
public class ATMStatusService {

    public String getATMStatus() {
        // In a real scenario, implement health checks (e.g., connectivity, device status)
        return "ATM is operational";
    }
}