package com.app.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.MediaFile;
import com.app.service.MediaService;

@RestController
@RequestMapping("/api/v1/media")
public class MediaController {
    @Autowired
    private MediaService mediaService;

    @GetMapping("/download")
    public List<MediaFile> getMediaFiles(@RequestParam("startTime") LocalDateTime startTime,
                                         @RequestParam("endTime") LocalDateTime endTime) {
        return mediaService.getMediaFilesByTimeRange(startTime, endTime);
    }
}
