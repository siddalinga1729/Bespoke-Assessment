package com.app.controller;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.app.entity.Transaction;
import com.app.service.TransactionService;

@RestController
@RequestMapping("/api/v1")
public class TransactionController {
    @Autowired
    private TransactionService transactionService;

    @GetMapping("/customers/last-24-hours")
    public List<Transaction> getTransactionsInLast24Hours() {
        return transactionService.getTransactionsInLast24Hours();
    }
    
    @GetMapping("/transactions/history")
    public List<Transaction> getTransactionHistory(@RequestParam("startTime") LocalDateTime startTime,
                                                   @RequestParam("endTime") LocalDateTime endTime) {
        return transactionService.getTransactionHistory(startTime, endTime);
    }

}
