package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.entity.FailureLog;
import com.app.service.FailureLogService;

@RestController
@RequestMapping("/api/v1/failures")
public class FailureLogController {
    @Autowired
    private FailureLogService failureLogService;

    @GetMapping
    public List<FailureLog> getAllFailures() {
        return failureLogService.getAllFailures();
    }

    @PostMapping
    public FailureLog addFailure(@RequestBody FailureLog failureLog) {
        return failureLogService.addFailure(failureLog);
    }
}