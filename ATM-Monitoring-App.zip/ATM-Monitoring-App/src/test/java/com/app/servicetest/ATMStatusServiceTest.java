package com.app.servicetest;

import org.junit.jupiter.api.Test;

import com.app.service.ATMStatusService;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ATMStatusServiceTest {
	private final ATMStatusService atmStatusService = new ATMStatusService();

    @Test
    void testGetATMStatus() {
        // Act
        String status = atmStatusService.getATMStatus();

        // Assert
        assertEquals("ATM is operational", status);
    }
}
