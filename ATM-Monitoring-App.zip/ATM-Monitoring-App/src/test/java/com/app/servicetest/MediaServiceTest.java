package com.app.servicetest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.app.entity.MediaFile;
import com.app.repo.MediaFileRepository;
import com.app.service.MediaService;

public class MediaServiceTest {
	@Mock
	private MediaFileRepository mediaFileRepository;

	@InjectMocks
	private MediaService mediaService;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testGetMediaFilesByTimeRange() {
		// Arrange
		LocalDateTime startTime = LocalDateTime.now().minusDays(1);
		LocalDateTime endTime = LocalDateTime.now();
		List<MediaFile> mediaFiles = Arrays.asList(
				new MediaFile(1L, "/path/to/media1.mp4", startTime, endTime.minusHours(1)),
				new MediaFile(2L, "/path/to/media2.mp4", startTime.plusHours(1), endTime));

		when(mediaFileRepository.findByStartTimeBetween(startTime, endTime)).thenReturn(mediaFiles);

		// Act
		List<MediaFile> result = mediaService.getMediaFilesByTimeRange(startTime, endTime);

		// Assert
		assertEquals(2, result.size());
		assertEquals("/path/to/media1.mp4", result.get(0).getFilePath());
	}
}
