package com.app.servicetest;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.app.entity.FailureLog;
import com.app.repo.FailureLogRepository;
import com.app.service.FailureLogService;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class FailureLogServiceTest {
	@Mock
    private FailureLogRepository failureLogRepository;
	
    @InjectMocks
    private FailureLogService failureLogService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetAllFailures() {
        // Arrange
        List<FailureLog> failureLogs = Arrays.asList(
                new FailureLog(1L, "SYSTEM", "System failure occurred", LocalDateTime.now()),
                new FailureLog(2L, "DEVICE", "Device error", LocalDateTime.now())
        );

        when(failureLogRepository.findAll()).thenReturn(failureLogs);
        

        // Act
        List<FailureLog> result = failureLogService.getAllFailures();

        // Assert
        assertEquals(2, result.size());
        assertEquals("SYSTEM", result.get(0).getErrorType());
    }

    @Test
    void testAddFailure() {
        // Arrange
        FailureLog failureLog = new FailureLog(null, "DEVICE", "ATM device failure", LocalDateTime.now());
        FailureLog savedFailureLog = new FailureLog(1L, "DEVICE", "ATM device failure", LocalDateTime.now());

        when(failureLogRepository.save(failureLog)).thenReturn(savedFailureLog);

        // Act
        FailureLog result = failureLogService.addFailure(failureLog);

        // Assert
        assertEquals(1L, result.getId());
        assertEquals("DEVICE", result.getErrorType());
    }
}
